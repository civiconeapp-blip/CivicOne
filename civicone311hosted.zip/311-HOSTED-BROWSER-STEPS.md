# Finish the one-tap 311 feature — hosted browser

The 311 feature is fully built. The only remaining piece is giving it a hosted
browser to drive SF311's form (a full browser can't run inside Vercel reliably).

## 1. Get a free Browserbase account (2 min)
- Go to browserbase.com, sign up.
- In the dashboard, copy your **API Key** and your **Project ID**.
  (Browserbase has a free tier that's plenty for this.)

## 2. Update 3 files in the repo
Upload these over the existing ones (GitHub → Add file → Upload files):
- `lib/submit311.js`   (now connects to the hosted browser)
- `package.json`       (removes the in-Vercel chromium package)
- `vercel.json`        (adjusts the function settings)

## 3. Add env vars in Vercel (civic-one project → Settings → Environment Variables)
- `BROWSERBASE_API_KEY`     = your Browserbase API key
- `BROWSERBASE_PROJECT_ID`  = your Browserbase project ID
- `REPORTER_EMAIL`          = your email (fallback for forms that require one)
- (optional) `DRY_RUN` = 1  to test without filing a real report; remove to go live

Then Deployments → newest → ⋯ → Redeploy.

## 4. Test
Open the 311 section, snap a photo. You should get a real SF311 case number.

Already have GEMINI_API_KEY set (used for the AI). Nothing else changes:
every report still ends with "Reported by CivicOne." and residents can enter
their own email for case updates.

## Alternative to Browserbase
If you prefer Browserless (browserless.io), set BROWSERLESS_WS instead, e.g.
wss://production-sfo.browserless.io/chromium/playwright?token=YOUR_TOKEN

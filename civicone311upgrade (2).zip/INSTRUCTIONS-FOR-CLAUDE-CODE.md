# Apply the one-tap 311 upgrade to CivicOne

This folder contains drop-in files for the CivicOne repo. They replace the old
"prepare a report → copy → finish on SF311.org" flow with true one-tap filing:
photo + GPS → Gemini identifies the issue and writes the report → a headless
browser submits SF311's official Verint web form → the real SR case number is
shown to the resident. Validated live: SR #101004607626 was filed through this
exact flow on 2026-08-12.

## Files

NEW:
- `api/report.js`      — serverless function: geocode + Gemini vision + auto-file
- `lib/forms311.js`    — SF311 Verint form registry (slugs + category values)
- `lib/submit311.js`   — Playwright engine that drives the SF311 form

MODIFIED (full replacements):
- `src/ReportForm.jsx` — one-tap UI in the City Briefing design system, i18n'd
- `src/i18n.js`        — 14 new keys added to all 5 languages
- `src/App.jsx`        — one line: passes `lang` prop to ReportForm
- `package.json`       — adds `@sparticuz/chromium` + `playwright-core`
- `vercel.json`        — function config: maxDuration 60, memory 1769

## Steps

1. Copy all files into the repo at the same paths (overwrite).
2. `npm install` (updates package-lock.json).
3. `npm run build` to confirm the build passes.
4. Commit and push to main — Vercel auto-deploys.

## Vercel settings (do once, in the civic-one project)

- `GEMINI_API_KEY` — already set (used by api/triage.js).
- Add `REPORTER_EMAIL` — fallback email; some SF311 forms (street cleaning)
  require one even for anonymous reports. The UI also has an optional email
  field: when a resident enters theirs, it is used instead so 311 sends the
  case updates to them.
- Optional: add `DRY_RUN=1` to test safely (walks the SF311 form to the review
  page but never submits). Remove it to go live. Health check:
  GET /api/report returns `{ok, hasKey, hasEmail, dryRun}`.

## Notes

- Every description is tagged "Reported by CivicOne." — same convention
  Solve SF used ("Reported by SolveSF.").

- api/triage.js is no longer called by the UI but is left in place (harmless).
- If SF311 changes their form, update selectors in `lib/submit311.js`;
  category values live in `lib/forms311.js`.
